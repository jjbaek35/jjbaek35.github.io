python -m http.server 8080
Open browser with http://127.0.0.1:8080


python demo_server.py
Open browser with http://127.0.0.1:8000
